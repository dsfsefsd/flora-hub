from TikTokLive import TikTokLiveClient
from TikTokLive.events import ConnectEvent, CommentEvent, GiftEvent, ShareEvent, FollowEvent, LikeEvent, JoinEvent
import os
import time
from datetime import datetime
from threading import Thread

class MauSac:
    TRANG = '\033[97m'
    XANH_LA = '\033[92m'
    XANH_DUONG = '\033[94m'
    VANG = '\033[93m'
    DO = '\033[91m'
    TIM = '\033[95m'
    XANH_NGOC = '\033[96m'
    HONG = '\033[95m'
    DAM = '\033[1m'
    KET_THUC = '\033[0m'

class TheoDoiLiveStream:
    def __init__(self):
        self.thong_ke = {
            'nguoi_xem': 0,
            'luot_thich': 0,
            'chia_se': 0,
            'kim_cuong': 0,
            'follow': 0
        }
        self.nguoi_xem_dang_xem = set()
        self.ten_file_log = None

    def cap_nhat_thong_ke(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"""
{MauSac.XANH_NGOC}╔════════════════════════════════════════════════════════════════════╗
║ THỐNG KÊ TRỰC TIẾP:                                                  ║
║ 👻 Tổng xem: {len(self.nguoi_xem_dang_xem)} | ❤️ Tim: {self.thong_ke['luot_thich']} | 💎 KC: {self.thong_ke['kim_cuong']}     ║
║ 🌟 Follow: {self.thong_ke['follow']} | 📤 Share: {self.thong_ke['chia_se']}                                                   ║
╚════════════════════════════════════════════════════════════════════╝
{MauSac.KET_THUC}""")
        
    def tao_file_log(self, ten_nguoi_dung):
        # Tạo tên file log với timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        ten_file = f"comments_{ten_nguoi_dung}_{timestamp}.txt"
        self.ten_file_log = ten_file
        
        # Tạo header cho file
        with open(ten_file, 'w', encoding='utf-8') as f:
            f.write(f"LOG BÌNH LUẬN CHO STREAM CỦA {ten_nguoi_dung}\n")
            f.write(f"Bắt đầu lúc: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 50 + "\n\n")

    def ghi_binh_luan(self, thoi_gian, nickname, noi_dung):
        if self.ten_file_log:
            with open(self.ten_file_log, 'a', encoding='utf-8') as f:
                f.write(f"[{thoi_gian}] {nickname}: {noi_dung}\n")

def main():
    theo_doi = TheoDoiLiveStream()
    
    while True:
        ten_nguoi_dung = input(f"{MauSac.VANG}Nhập tên người dùng TikTok (không cần @) hoặc 'thoat' để kết thúc: {MauSac.KET_THUC}").strip()
        
        if ten_nguoi_dung.lower() == 'thoat':
            break

        if not ten_nguoi_dung:
            continue

        if not ten_nguoi_dung.startswith('@'):
            ten_nguoi_dung = f'@{ten_nguoi_dung}'

        # Tạo file log khi bắt đầu theo dõi người dùng mới
        theo_doi.tao_file_log(ten_nguoi_dung.replace('@', ''))

        client = TikTokLiveClient(unique_id=ten_nguoi_dung)

        @client.on(ConnectEvent)
        async def khi_ket_noi(event):
            theo_doi.cap_nhat_thong_ke()
            print(f"{MauSac.XANH_LA}[✓] Đã kết nối tới: {event.unique_id}{MauSac.KET_THUC}\n")

        @client.on(CommentEvent)
        async def khi_co_binh_luan(event):
            thoi_gian = datetime.now().strftime("%H:%M:%S")
            print(f"{MauSac.TRANG}[{thoi_gian}] 💭 {MauSac.VANG}{event.user.nickname}{MauSac.TRANG}: {event.comment}{MauSac.KET_THUC}")
            # Lưu bình luận vào file
            theo_doi.ghi_binh_luan(thoi_gian, event.user.nickname, event.comment)

        @client.on(GiftEvent)
        async def khi_co_qua_tang(event):
            thoi_gian = datetime.now().strftime("%H:%M:%S")
            theo_doi.thong_ke['kim_cuong'] += event.gift.diamonds * event.gift.count
            print(f"{MauSac.HONG}[{thoi_gian}] 🎁 {event.user.nickname} tặng {event.gift.name} x{event.gift.count} (💎{event.gift.diamonds * event.gift.count}){MauSac.KET_THUC}")

        @client.on(JoinEvent)
        async def khi_co_nguoi_tham_gia(event):
            theo_doi.nguoi_xem_dang_xem.add(event.user.unique_id)
            thoi_gian = datetime.now().strftime("%H:%M:%S")
            print(f"{MauSac.XANH_NGOC}[{thoi_gian}] 👋 {event.user.nickname} đã tham gia stream{MauSac.KET_THUC}")

        @client.on(FollowEvent)
        async def khi_co_nguoi_follow(event):
            theo_doi.thong_ke['follow'] += 1
            thoi_gian = datetime.now().strftime("%H:%M:%S")
            print(f"{MauSac.XANH_LA}[{thoi_gian}] ✨ {event.user.nickname} đã follow{MauSac.KET_THUC}")

        @client.on(LikeEvent)
        async def khi_co_luot_thich(event):
            theo_doi.thong_ke['luot_thich'] += 1
            thoi_gian = datetime.now().strftime("%H:%M:%S")
            print(f"{MauSac.DO}[{thoi_gian}] ❤️ {event.user.nickname} đã thả tim{MauSac.KET_THUC}")

        @client.on(ShareEvent)
        async def khi_co_chia_se(event):
            theo_doi.thong_ke['chia_se'] += 1
            thoi_gian = datetime.now().strftime("%H:%M:%S")
            print(f"{MauSac.XANH_DUONG}[{thoi_gian}] 📤 {event.user.nickname} đã chia sẻ stream{MauSac.KET_THUC}")

        def cap_nhat_dinh_ky():
            while True:
                theo_doi.cap_nhat_thong_ke()
                time.sleep(5)

        thread_cap_nhat = Thread(target=cap_nhat_dinh_ky)
        thread_cap_nhat.daemon = True
        thread_cap_nhat.start()

        try:
            print(f"\n{MauSac.VANG}Đang kết nối tới live stream của {ten_nguoi_dung}...{MauSac.KET_THUC}")
            client.run()
        except Exception as e:
            print(f"\n{MauSac.DO}Lỗi: {str(e)}{MauSac.KET_THUC}")
        except KeyboardInterrupt:
            print(f"\n{MauSac.VANG}Đã dừng xem stream{MauSac.KET_THUC}")

        thu_lai = input(f"\n{MauSac.VANG}Bạn có muốn thử username khác không? (y/n): {MauSac.TRANG}").strip().lower()
        if thu_lai != 'y':
            break

    print(f"\n{MauSac.XANH_LA}Cảm ơn bạn đã sử dụng tool!{MauSac.KET_THUC}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{MauSac.DO}Đã dừng chương trình bởi người dùng{MauSac.KET_THUC}")
    except Exception as e:
        print(f"\n{MauSac.DO}Lỗi không mong muốn: {str(e)}{MauSac.KET_THUC}")