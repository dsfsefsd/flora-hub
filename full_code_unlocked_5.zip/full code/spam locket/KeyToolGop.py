import requests
import base64
import json
import os
from datetime import datetime, timedelta, timezone
from time import sleep

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_shortened_yeumoney(url):
    token = 'a7b964c8e63035ecb520ab53461f8aa9c0c5c037ff13966faaa441a739502752'
    try:
        resp = requests.get(f'https://yeumoney.com/QL_api.php?token={token}&format=json&url={url}')
        if resp.status_code == 200:
            data = resp.json()
            if data.get('status') == 'success':
                return data.get('shortenedUrl')
    except: pass
    return None

def save_key_info(key_data):
    try:
        with open('key.json', 'w') as f:
            json.dump(key_data, f)
    except: pass

def load_key_info():
    try:
        with open('key.json', 'r') as f:
            return json.load(f)
    except: return None

def check_key_validation():
    return True, 'normal'

def show_menu():
    clear_screen()
    
    print("\033[1;36m================================\033[0m")
    print("\033[1;33m        SYSTEM KEY CHECK        \033[0m")
    print("\033[1;36m================================\033[0m")
    print("\033[1;32m[1] Vượt Key Thường (6h)\033[0m")
    print("\033[1;33m[2] Vượt Key VIP (24h)\033[0m")
    print("\033[1;31m[3] Thoát\033[0m")
    print("\033[1;36m================================\033[0m")
    choice = input("\033[1;37mNhập lựa chọn của bạn (1-3): \033[0m")
    return choice

def key_verify(type='normal'):
    is_valid, key_type = check_key_validation()
    if is_valid:
        key_name = "VIP" if key_type == "vip" else "Thường"
        print(f"\033[1;32mKey {key_name} còn hạn sử dụng. Tiếp tục...\033[0m")
        sleep(1)
        return True

    current_time = datetime.now()
    verify_key = base64.b64encode(str(current_time.timestamp()).encode()).decode()[:16]
    
    if type == 'vip':
        expiry_time = current_time + timedelta(hours=24)
        steps = 3
    else:
        expiry_time = current_time + timedelta(hours=6)
        steps = 1

    for step in range(1, steps + 1):
        current_utc = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        verify_url = f"https://nguyennamtien.shop/key/?key={verify_key}&step={step}&total={steps}&time={current_utc}&user=tiendev5"
        short_url = get_shortened_yeumoney(verify_url)

        if not short_url:
            print("\033[1;31mLỗi tạo link xác thực\033[0m")
            return False

        if steps > 1:
            print(f"\033[1;33mBước {step}/{steps} - Vui lòng truy cập link:\033[0m")
        else:
            print("\033[1;33mVui lòng truy cập link để lấy key:\033[0m")
        print(f"\033[1;36m{short_url}\033[0m")

        attempts = 3
        while attempts > 0:
            user_input = input(f"\033[1;37mNhập key{' cho bước ' + str(step) if steps > 1 else ''}: \033[0m")
            
            if user_input.lower() == 'exit':
                print("\033[1;31mĐã hủy quá trình xác thực.\033[0m")
                return False
                
            if user_input == verify_key:
                if step == steps:
                    save_key_info({
                        'key': verify_key,
                        'type': type,
                        'expiry': expiry_time.isoformat(),
                        'created_at': datetime.now(timezone.utc).isoformat(),
                        'created_by': 'tiendev5'
                    })
                    print("\033[1;32mXác thực thành công!\033[0m")
                    sleep(1)
                break
            else:
                attempts -= 1
                if attempts > 0:
                    print(f"\033[1;31mKey sai! Còn {attempts} lần thử\033[0m")

        if attempts == 0:
            print("\033[1;31mQuá nhiều lần thử. Vui lòng thử lại sau.\033[0m")
            return False

        if step < steps:
            print(f"\033[1;32mBước {step} hoàn thành! Tiếp tục bước tiếp theo...\033[0m")
            sleep(1)

    return True

def main():
    while True:
        choice = show_menu()
        
        if choice == '1':
            if not key_verify('normal'):
                print("\033[1;31mXác thực key thường thất bại!\033[0m")
                sleep(2)
                continue
            return True
            
        elif choice == '2':
            if not key_verify('vip'):
                print("\033[1;31mXác thực key VIP thất bại!\033[0m")
                sleep(2)
                continue
            return True
            
        elif choice == '3':
            print("\033[1;31mĐã thoát chương trình.\033[0m")
            exit()
            
        else:
            print("\033[1;31mLựa chọn không hợp lệ!\033[0m")
            sleep(2)

if __name__ == "__main__":
    if not main():
        exit()