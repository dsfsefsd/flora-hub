def thanhngang(soluong=70):
    print("-" * soluong)

thanh = "[🌀] "

