import sys
import os
import json
import time
import shutil
import schedule
from datetime import datetime
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QTextEdit, QPushButton, QGroupBox, QTimeEdit,
    QTabWidget, QColorDialog, QMessageBox
)
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon
import qdarkstyle

from fbchat import Client, Message, ThreadType

# Selenium để mở Chrome login và lấy cookie
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

CONFIG_FILE = "config.json"

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r", encoding="utf8") as f:
        return json.load(f)

def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf8") as f:
        json.dump(config, f, ensure_ascii=False, indent=4)

def chrome_login_and_get_cookie():
    # Chạy Chrome tự động để login Facebook
    chrome_options = Options()
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_argument("--start-maximized")
    # chrome_options.add_argument("--headless") # nếu không muốn hiện cửa sổ thì bật dòng này

    driver = webdriver.Chrome(options=chrome_options)
    driver.get("https://www.facebook.com/login")
    QMessageBox.information(None, "Đăng nhập Facebook", "Vui lòng đăng nhập Facebook trong trình duyệt Chrome vừa mở. Sau khi đăng nhập thành công, nhấn OK để trích xuất cookie.")
    cookies = driver.get_cookies()
    driver.quit()
    cookie_dict = {}
    for c in cookies:
        cookie_dict[c['name']] = c['value']
    return cookie_dict

class MessengerClient(Client):
    def __init__(self, cookies, auto_replies, parent=None):
        self.auto_replies = auto_replies
        self.parent = parent
        super().__init__(session_cookies=cookies)
        self.last_mid = None

    def onMessage(self, author_id=None, message_object=None, thread_id=None, thread_type=None, **kwargs):
        if author_id == self.uid:
            return
        received_text = message_object.text or ""
        for rule in self.auto_replies:
            if rule["pattern"].lower() in received_text.lower():
                reply = rule["reply"]
                super().send(Message(text=reply), thread_id=thread_id, thread_type=thread_type)
                self.parent.append_log(f"Auto-replied to {thread_id}: {reply}")
                break

class SchedulerThread(QThread):
    log_signal = pyqtSignal(str)
    send_signal = pyqtSignal(str)
    def __init__(self, schedule_times, message, recipient_id):
        super().__init__()
        self.schedule_times = schedule_times
        self.message = message
        self.recipient_id = recipient_id
        self.running = True

    def run(self):
        schedule.clear()
        for label, t in self.schedule_times.items():
            h, m = map(int, t.split(":"))
            schedule.every().day.at(f"{h:02d}:{m:02d}").do(self.do_send, label)
        while self.running:
            schedule.run_pending()
            time.sleep(10)

    def do_send(self, label):
        log = f"Gửi tin nhắn tự động lúc {label} ({datetime.now().strftime('%H:%M')})"
        self.log_signal.emit(log)
        self.send_signal.emit(f"Tự động ({label})")

    def stop(self):
        self.running = False

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Messenger Auto Bot PRO")
        self.setWindowIcon(QIcon("icon.png") if os.path.exists("icon.png") else QIcon())
        self.setGeometry(200, 100, 900, 650)
        self.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
        self.config = load_config()
        self.client = None
        self.scheduler_thread = None
        self._setup_ui()
        self._load_config_to_ui()

    def _setup_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # Tabbed Interface
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        # Tab 1: Đăng nhập
        self.tab_login = QWidget()
        login_layout = QVBoxLayout(self.tab_login)
        group = QGroupBox("Đăng nhập Facebook")
        form = QFormLayout()
        self.txt_cookie = QTextEdit()
        self.txt_cookie.setPlaceholderText("Cookie Facebook dạng JSON hoặc raw string")
        self.btn_login = QPushButton("Đăng nhập")
        self.btn_login.clicked.connect(self.do_login)
        self.btn_auto_cookie = QPushButton("Mở trình duyệt để login Facebook & lấy cookie")
        self.btn_auto_cookie.clicked.connect(self.on_auto_cookie)
        self.lbl_login_status = QLabel("Chưa đăng nhập")
        self.lbl_login_status.setStyleSheet("color: orange;")
        form.addRow("Cookie:", self.txt_cookie)
        form.addRow(self.btn_auto_cookie, self.btn_login)
        form.addRow(self.lbl_login_status)
        group.setLayout(form)
        login_layout.addWidget(group)
        self.tabs.addTab(self.tab_login, "Đăng nhập")

        # Tab 2: Cấu hình nhắn tin
        self.tab_msg = QWidget()
        msg_layout = QVBoxLayout(self.tab_msg)
        group2 = QGroupBox("Cấu hình gửi tin nhắn")
        f2 = QFormLayout()
        self.txt_uid = QLineEdit()
        self.txt_uid.setPlaceholderText("Dán link Facebook hoặc ID")
        self.txt_msg = QTextEdit()
        self.txt_msg.setPlaceholderText("Nội dung tin nhắn tự động")
        self.time_morning = QTimeEdit()
        self.time_noon = QTimeEdit()
        self.time_evening = QTimeEdit()
        self.time_morning.setDisplayFormat("HH:mm")
        self.time_noon.setDisplayFormat("HH:mm")
        self.time_evening.setDisplayFormat("HH:mm")
        htimes = QHBoxLayout()
        htimes.addWidget(QLabel("Sáng:"))
        htimes.addWidget(self.time_morning)
        htimes.addWidget(QLabel("Trưa:"))
        htimes.addWidget(self.time_noon)
        htimes.addWidget(QLabel("Tối:"))
        htimes.addWidget(self.time_evening)
        self.btn_test_send = QPushButton("Test gửi")
        self.btn_test_send.clicked.connect(self.on_test_send)
        self.btn_save = QPushButton("Lưu cấu hình")
        self.btn_save.clicked.connect(self.save_config_from_ui)
        f2.addRow("User ID/Messenger:", self.txt_uid)
        f2.addRow("Nội dung:", self.txt_msg)
        f2.addRow(htimes)
        f2.addRow(self.btn_test_send, self.btn_save)
        group2.setLayout(f2)
        msg_layout.addWidget(group2)
        self.tabs.addTab(self.tab_msg, "Gửi tin nhắn")

        # Tab 3: Auto reply
        self.tab_reply = QWidget()
        reply_layout = QVBoxLayout(self.tab_reply)
        group3 = QGroupBox("Cấu hình auto-reply")
        v = QVBoxLayout()
        self.txt_auto_reply = QTextEdit()
        self.txt_auto_reply.setPlaceholderText("pattern1|reply1\npattern2|reply2\n...")
        v.addWidget(self.txt_auto_reply)
        group3.setLayout(v)
        reply_layout.addWidget(group3)
        self.tabs.addTab(self.tab_reply, "Auto-reply")

        # Tab 4: Giao diện
        self.tab_ui = QWidget()
        ui_layout = QVBoxLayout(self.tab_ui)
        group4 = QGroupBox("Giao diện & Hiệu ứng")
        v2 = QVBoxLayout()
        self.btn_color = QPushButton("Chọn màu chủ đạo")
        self.btn_color.clicked.connect(self.choose_color)
        self.lbl_color = QLabel("Màu hiện tại: #23272A")
        v2.addWidget(self.btn_color)
        v2.addWidget(self.lbl_color)
        group4.setLayout(v2)
        ui_layout.addWidget(group4)
        self.tabs.addTab(self.tab_ui, "Giao diện")

        # Tab 5: Log & Start
        self.tab_log = QWidget()
        log_layout = QVBoxLayout(self.tab_log)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.btn_start = QPushButton("Bắt đầu auto")
        self.btn_start.clicked.connect(self.on_start)
        self.btn_stop = QPushButton("Dừng auto")
        self.btn_stop.clicked.connect(self.on_stop)
        self.btn_stop.setEnabled(False)
        hlayout = QHBoxLayout()
        hlayout.addWidget(self.btn_start)
        hlayout.addWidget(self.btn_stop)
        log_layout.addWidget(self.txt_log)
        log_layout.addLayout(hlayout)
        self.tabs.addTab(self.tab_log, "Log")

    def _load_config_to_ui(self):
        cfg = self.config
        self.txt_cookie.setText(cfg.get("cookie", ""))
        self.txt_uid.setText(cfg.get("recipient_id", ""))
        self.txt_msg.setText(cfg.get("message", ""))
        self.time_morning.setTime(self._str2time(cfg.get("time_morning", "07:00")))
        self.time_noon.setTime(self._str2time(cfg.get("time_noon", "12:00")))
        self.time_evening.setTime(self._str2time(cfg.get("time_evening", "18:00")))
        self.txt_auto_reply.setText("\n".join([f"{r['pattern']}|{r['reply']}" for r in cfg.get("auto_replies", [])]))
        color = cfg.get("color", "#23272A")
        self.lbl_color.setText(f"Màu hiện tại: {color}")
        pal = self.palette()
        pal.setColor(QPalette.Window, QColor(color))
        self.setPalette(pal)

    def _str2time(self, t):
        if not t: return self.time_morning.minimumTime()
        h, m = map(int, t.split(":"))
        return self.time_morning.time().fromString(f"{h:02d}:{m:02d}", "HH:mm")

    def save_config_from_ui(self):
        auto_replies = []
        for line in self.txt_auto_reply.toPlainText().splitlines():
            if "|" in line:
                pattern, reply = line.split("|", 1)
                auto_replies.append({"pattern": pattern.strip(), "reply": reply.strip()})
        color = self.lbl_color.text().replace("Màu hiện tại: ", "")
        self.config = {
            "cookie": self.txt_cookie.toPlainText(),
            "recipient_id": self.txt_uid.text(),
            "message": self.txt_msg.toPlainText(),
            "time_morning": self.time_morning.time().toString("HH:mm"),
            "time_noon": self.time_noon.time().toString("HH:mm"),
            "time_evening": self.time_evening.time().toString("HH:mm"),
            "auto_replies": auto_replies,
            "color": color
        }
        save_config(self.config)
        self.append_log("Đã lưu cấu hình.")

    def do_login(self):
        try:
            raw = self.txt_cookie.toPlainText().strip()
            if raw.startswith("{"):
                cookies = json.loads(raw)
            else:
                cookies = {}
                for x in raw.split(";"):
                    if "=" in x:
                        k, v = x.strip().split("=", 1)
                        cookies[k.strip()] = v.strip()
            self.client = MessengerClient(cookies, self._get_auto_replies(), self)
            self.lbl_login_status.setText("Đăng nhập thành công!")
            self.lbl_login_status.setStyleSheet("color: green;")
            self.append_log("Đã đăng nhập Facebook thành công.")
        except Exception as e:
            self.lbl_login_status.setText(f"Lỗi: {e}")
            self.lbl_login_status.setStyleSheet("color: red;")
            self.append_log(f"Lỗi đăng nhập: {e}")

    def _get_auto_replies(self):
        auto_replies = []
        for line in self.txt_auto_reply.toPlainText().splitlines():
            if "|" in line:
                pattern, reply = line.split("|", 1)
                auto_replies.append({"pattern": pattern.strip(), "reply": reply.strip()})
        return auto_replies

    def on_test_send(self):
        if not self.client:
            self.append_log("Bạn cần đăng nhập trước.")
            return
        toid = self.txt_uid.text().strip().replace("https://www.facebook.com/", "")
        msg = self.txt_msg.toPlainText()
        try:
            self.client.send(Message(text=msg), thread_id=toid, thread_type=ThreadType.USER)
            self.append_log("Đã gửi test.")
        except Exception as e:
            self.append_log(f"Lỗi gửi: {e}")

    def on_start(self):
        self.save_config_from_ui()
        if not self.client:
            self.append_log("Bạn cần đăng nhập trước.")
            return
        schedule_times = {
            "Sáng": self.time_morning.time().toString("HH:mm"),
            "Trưa": self.time_noon.time().toString("HH:mm"),
            "Tối": self.time_evening.time().toString("HH:mm"),
        }
        self.scheduler_thread = SchedulerThread(schedule_times, self.txt_msg.toPlainText(), self.txt_uid.text())
        self.scheduler_thread.log_signal.connect(self.append_log)
        self.scheduler_thread.send_signal.connect(self.send_auto_message)
        self.scheduler_thread.start()
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.append_log("Bắt đầu auto gửi tin nhắn.")

    def on_stop(self):
        if self.scheduler_thread:
            self.scheduler_thread.stop()
            self.scheduler_thread = None
            self.append_log("Đã dừng auto gửi.")
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)

    def send_auto_message(self, label):
        try:
            toid = self.txt_uid.text().strip().replace("https://www.facebook.com/", "")
            msg = self.txt_msg.toPlainText()
            self.client.send(Message(text=f"{msg}\n(Gửi tự động: {label})"), thread_id=toid, thread_type=ThreadType.USER)
            self.append_log(f"Đã gửi tự động ({label}).")
        except Exception as e:
            self.append_log(f"Lỗi gửi auto: {e}")

    def choose_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.lbl_color.setText(f"Màu hiện tại: {color.name()}")
            pal = self.palette()
            pal.setColor(QPalette.Window, color)
            self.setPalette(pal)
            self.config["color"] = color.name()

    def append_log(self, text):
        self.txt_log.append(f"[{datetime.now().strftime('%H:%M:%S')}] {text}")

    def closeEvent(self, event):
        if self.scheduler_thread:
            self.scheduler_thread.stop()
        self.save_config_from_ui()
        super().closeEvent(event)

    def on_auto_cookie(self):
        try:
            self.append_log("Đang mở Chrome để login Facebook...")
            cookies = chrome_login_and_get_cookie()
            self.txt_cookie.setText(json.dumps(cookies, ensure_ascii=False, indent=2))
            self.append_log("Đã lấy cookie từ Chrome thành công.")
        except Exception as e:
            self.append_log(f"Lỗi lấy cookie từ Chrome: {e}")
            QMessageBox.warning(self, "Lỗi lấy cookie", str(e))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())