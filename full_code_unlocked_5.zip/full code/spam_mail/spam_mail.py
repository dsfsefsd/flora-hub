import smtplib
import time
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr, make_msgid
from datetime import datetime
import sys
import random
import socket
from typing import List
import threading
import colorama
import requests
import base64
import json
import os
from datetime import datetime, timedelta
from time import sleep

def get_shortened_yeumoney(url):
    token = 'a7b964c8e63035ecb520ab53461f8aa9c0c5c037ff13966faaa441a739502752'
    try:
        resp = requests.get(f'https://yeumoney.com/QL_api.php?token={token}&format=json&url={url}')
        if resp.status_code == 200:
            data = resp.json()
            if data.get('status') == 'success':
                return data.get('shortenedUrl')
    except: pass
    return None

def save_key_info(key_data):
    try:
        with open('key.json', 'w') as f:
            json.dump(key_data, f)
    except: pass

def load_key_info():
    try:
        with open('key.json', 'r') as f:
            return json.load(f)
    except: return None

def check_key_validation():
    try:
        key_data = load_key_info()
        if key_data:
            expiry = datetime.fromisoformat(key_data['expiry'])
            if datetime.now() < expiry:
                return True
    except: pass
    return False

def key_verify():
    if check_key_validation():
        print("\033[1;32mKey còn hạn sử dụng. Tiếp tục...\033[0m")
        return True

    current_time = datetime.now()
    expiry_time = current_time + timedelta(hours=6)
    verify_key = base64.b64encode(str(current_time.timestamp()).encode()).decode()[:16]
    
    verify_url = f"https://nguyennamtien.shop/key/?key={verify_key}"
    short_url = get_shortened_yeumoney(verify_url)

    if not short_url:
        print("\033[1;31mLỗi tạo link xác thực\033[0m")
        return False

    print("\033[1;33mVui lòng truy cập link để lấy key:\033[0m")
    print(f"\033[1;36m{short_url}\033[0m")

    for i in range(3):
        user_input = input("\033[1;37mNhập key: \033[0m")
        if user_input == verify_key:
            save_key_info({
                'key': verify_key,
                'expiry': expiry_time.isoformat()
            })
            print("\033[1;32mXác thực thành công!\033[0m")
            sleep(1)
            return True
        else:
            print(f"\033[1;31mKey sai! Còn {2-i} lần thử\033[0m")

    print("\033[1;31mQuá nhiều lần thử. Vui lòng thử lại sau.\033[0m")
    return False


colorama.init()

class Colors:
    BLACK = "\033[0;30m"
    RED = "\033[0;31m"
    GREEN = "\033[0;32m"
    BROWN = "\033[0;33m"
    BLUE = "\033[0;34m"
    PURPLE = "\033[0;35m"
    CYAN = "\033[0;36m"
    LIGHT_GRAY = "\033[0;37m"
    DARK_GRAY = "\033[1;30m"
    LIGHT_RED = "\033[1;31m"
    LIGHT_GREEN = "\033[1;32m"
    YELLOW = "\033[1;33m"
    LIGHT_BLUE = "\033[1;34m"
    LIGHT_PURPLE = "\033[1;35m"
    LIGHT_CYAN = "\033[1;36m"
    LIGHT_WHITE = "\033[1;37m"
    BOLD = "\033[1m"
    FAINT = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"
    BLINK = "\033[5m"
    RESET = "\033[0m"
    NEGATIVE = "\033[7m"
    CROSSED = "\033[9m"
    END = "\033[0m"
    PINK = "\033[38;2;255;20;147m"

VERSION = "1.0.0"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_with_effect(text, delay=0.001):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def loading_effect(text):
    chars = "⣾⣽⣻⢿⡿⣟⣯⣷"
    colors = [Colors.RED, Colors.YELLOW, Colors.GREEN, Colors.BLUE, Colors.PURPLE, Colors.CYAN]
    for i in range(20):
        color = colors[i % len(colors)]
        char = chars[i % len(chars)]
        sys.stdout.write(f'\r{color}{text} {char}{Colors.END}')
        sys.stdout.flush()
        time.sleep(0.1)
    print()

def success_animation(text):
    print(f"\r{Colors.GREEN}[✓] {text}{Colors.END}")
    time.sleep(0.5)

def error_animation(text):
    print(f"\r{Colors.RED}[✗] {text}{Colors.END}")
    time.sleep(0.5)

def rainbow_text(text):
    colors = [Colors.RED, Colors.YELLOW, Colors.GREEN, Colors.BLUE, Colors.PURPLE, Colors.CYAN]
    colored_text = ""
    for i, char in enumerate(text):
        if char != " ":
            colored_text += colors[i % len(colors)] + char
        else:
            colored_text += char
    return colored_text + Colors.END

def print_banner():
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    banner = f"""
{Colors.PINK}┏━━━❨❨★ ❩❩━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❨❨★ ❩❩━━━┓

{Colors.LIGHT_RED}████████╗██╗███████╗███╗   ██╗██████╗ ███████╗██╗   ██╗
╚══██╔══╝██║██╔════╝████╗  ██║██╔══██╗██╔════╝██║   ██║
   ██║   ██║█████╗  ██╔██╗ ██║██║  ██║█████╗  ██║   ██║
   ██║   ██║██╔══╝  ██║╚██╗██║██║  ██║██╔══╝  ╚██╗ ██╔╝
   ██║   ██║███████╗██║ ╚████║██████╔╝███████╗ ╚████╔╝ 
   ╚═╝   ╚═╝╚══════╝╚═╝  ╚═══╝╚═════╝ ╚══════╝  ╚═══╝  

{Colors.LIGHT_CYAN}⭐️ DEVELOPER   : {Colors.LIGHT_WHITE}TienDev
{Colors.LIGHT_CYAN}⭐️ FACEBOOK    : {Colors.LIGHT_WHITE}https://facebook.com/tiendev.2000
{Colors.LIGHT_CYAN}⭐️ ZALO        : {Colors.LIGHT_WHITE}0347160155
{Colors.LIGHT_CYAN}⭐️ WEBSITE     : {Colors.LIGHT_WHITE}https://nguyennamtien.shop
{Colors.LIGHT_CYAN}⭐️ PHIÊN BẢN   : {Colors.LIGHT_WHITE}{VERSION} (Premium)
{Colors.LIGHT_CYAN}⭐️ THỜI GIAN   : {Colors.LIGHT_WHITE}{current_time}
{Colors.LIGHT_CYAN}⭐️ NGƯỜI DÙNG  : {Colors.LIGHT_WHITE}{os.getlogin()}

{Colors.LIGHT_PURPLE}                  ╭─━━━━━━━━━━━━━━━━━━━━─╮
                  │   TOOL SIÊU VIP PRO  │
                  ╰─━━━━━━━━━━━━━━━━━━━━─╯

{Colors.PINK}┗━━━❨❨★ ❩❩━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❨❨★ ❩❩━━━┛{Colors.END}
"""
    print_with_effect(banner, 0.0001)

def fancy_progress_bar(current: int, total: int, success: bool):
    progress = (current / total) * 100
    bar_length = 30
    filled_length = int(bar_length * current / total)
    
    if success:
        bar = Colors.GREEN + '━' * filled_length + Colors.YELLOW + '━' + Colors.DARK_GRAY + '━' * (bar_length - filled_length - 1)
        status = f"{Colors.GREEN}⬢"
    else:
        bar = Colors.RED + '━' * filled_length + Colors.YELLOW + '━' + Colors.DARK_GRAY + '━' * (bar_length - filled_length - 1)
        status = f"{Colors.RED}⬡"
    
    sys.stdout.write(f'\r{Colors.BLUE}Tiến độ: [{bar}{Colors.BLUE}] {Colors.YELLOW}{progress:0.1f}% {status}{Colors.END}')
    sys.stdout.flush()

def countdown_effect(seconds: int):
    """Đếm ngược với hiệu ứng"""
    for i in range(seconds, 0, -1):
        sys.stdout.write(f'\r{Colors.YELLOW}⏳ Đợi {i:2d} giây...{Colors.END}')
        sys.stdout.flush()
        time.sleep(1)
    sys.stdout.write('\r' + ' ' * 30 + '\r')

class EmailSender:
    def __init__(self, sender_email: str, app_password: str):
        self.sender_email = sender_email
        self.app_password = app_password

    def generate_fake_email(self) -> str:
        """Tạo email giả ngẫu nhiên"""
        chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
        prefixes = ['support', 'admin', 'service', 'info', 'system', 'security', 'help', 'contact']
        domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com']
        
        # Tạo username kết hợp prefix + số ngẫu nhiên
        prefix = random.choice(prefixes)
        numbers = ''.join(random.choice(chars) for _ in range(4))
        username = f"{prefix}{numbers}"
        
        # Chọn domain ngẫu nhiên
        domain = random.choice(domains)
        
        return f"{username}@{domain}"

    def generate_fake_name(self) -> str:
        """Tạo tên người gửi giả"""
        first_names = [
            'Security', 'System', 'Admin', 'Support', 'Service', 'Mail', 'Account', 'Notice',
            'Google', 'Microsoft', 'Apple', 'Email', 'Alert', 'Authentication', 'Verification',
            'Protection', 'Info', 'Help', 'Network', 'Cloud', 'Desktop', 'Mobile', 'Web',
            'Customer', 'Technical', 'Official', 'Secure', 'Database', 'Server', 'Platform',
            'Corporate', 'Enterprise', 'Business', 'Premium', 'Priority', 'Emergency', 'Urgent',
            'Identity', 'Access', 'Storage', 'Backup', 'Recovery', 'Management', 'Monitoring',
            'Notification', 'Communication', 'Messaging', 'Operations', 'Development', 'Application'
        ]
        
        last_names = [
            'Team', 'Center', 'Service', 'Alert', 'Support', 'System', 'Department',
            'Security', 'Administration', 'Management', 'Services', 'Operations', 'Group',
            'Division', 'Unit', 'Office', 'Desk', 'Hub', 'Portal', 'Platform', 'Network',
            'Solutions', 'Technologies', 'Systems', 'Infrastructure', 'Framework', 'Cloud',
            'Protection', 'Defense', 'Control', 'Monitoring', 'Analysis', 'Intelligence',
            'Verification', 'Authentication', 'Authorization', 'Validation', 'Notification',
            'Communications', 'Resources', 'Assistance', 'Help', 'Support', 'Care', 'Notice',
            'Alert', 'Warning', 'Attention', 'Priority', 'Emergency', 'Response', 'Action'
        ]
        
        return f"{random.choice(first_names)} {random.choice(last_names)}"

    def create_message(self, receiver_email: str, subject: str, body: str) -> tuple[MIMEMultipart, str, str]:
        message = MIMEMultipart('alternative')
        
        # Tạo thông tin giả
        fake_email = self.generate_fake_email()
        fake_name = self.generate_fake_name()
        
        message["From"] = f"{fake_name} <{fake_email}>"
        message["To"] = receiver_email
        message["Subject"] = subject
        
        message["Sender"] = fake_email
        message["Reply-To"] = fake_email
        message["Return-Path"] = fake_email
        message["X-Sender"] = fake_email
        message["X-Originating-Email"] = fake_email
        
        message["Message-ID"] = make_msgid(domain=fake_email.split('@')[1])
        message["Date"] = datetime.now().strftime("%a, %d %b %Y %H:%M:%S +0000")
        message["X-Priority"] = "1"
        
        # Nội dung email
        html_content = f"""
        <html>
        <body>
            <div style="font-family: Arial, sans-serif;">
                {body.replace('\n', '<br>')}
                <br><br>
                <div style="color: #666; font-size: 12px;">
                    From: {fake_name}<br>
                    Email: {fake_email}<br>
                    Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
                </div>
            </div>
        </body>
        </html>
        """
        
        message.attach(MIMEText(body, 'plain', 'utf-8'))
        message.attach(MIMEText(html_content, 'html', 'utf-8'))
        
        return message, fake_email, fake_name

    def send_email(self, receiver_email: str, subject: str, body: str) -> tuple[bool, str]:
        try:
            message, fake_email, fake_name = self.create_message(receiver_email, subject, body)
            
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.ehlo()
                server.starttls()
                server.ehlo()
                
                server.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                server.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                
                server.login(self.sender_email, self.app_password)
                
                server.sendmail(fake_email, receiver_email, message.as_string())
                
                return True, fake_email

        except Exception as e:
            print(f"{Colors.RED}Lỗi: {str(e)}{Colors.END}")
            return False, ""
        
        
class EmailBlocker:
    def __init__(self):
        self.blocked_emails = [
            "tiennguyen2k823@gmaill.com"
        ]
        self.block_reasons = {
            "tiennguyen2k823@gmail.com": "Email này của Admin không được spam nha hư lắm đó!"
        }

    def is_blocked(self, email: str) -> tuple[bool, str]:
        email = email.lower()
        if email in self.blocked_emails:
            return True, self.block_reasons.get(email, "Email này của Admin không được spam nha hư lắm đó!")
        return False, ""

def show_warning_banner(reason: str):
    print(f"\n{Colors.RED}╔═══════════════ CẢNH BÁO ═══════════════╗{Colors.END}")
    print(f"{Colors.RED}║{Colors.YELLOW} ⚠️  Email này của Admin bạn nỡ lòng nào!{' ' * 13}{Colors.RED}║{Colors.END}")
    print(f"{Colors.RED}║{Colors.YELLOW} ⚠️  Lý do: {reason}{' ' * (25 - len(reason))}{Colors.RED}║{Colors.END}")
    print(f"{Colors.RED}╚═══════════════════════════════════════════╝{Colors.END}")
    
    
def main():
    clear_screen()
    print_banner()
    
    email_blocker = EmailBlocker()
    
    loading_effect("Khởi động hệ thống")
    clear_screen()
    print_banner()


    gmail_accounts = []
    
    print(f"{Colors.YELLOW}[*] Nhập danh sách tài khoản Gmail (nhấn Enter trống để kết thúc):{Colors.END}")
    account_num = 1
    while True:
        print(f"\n{Colors.YELLOW}[*] Tài khoản Gmail {account_num}:{Colors.END}")
        email = input(f"{Colors.CYAN}[>] Email: {Colors.END}")
        if email == "":
            break
        password = input(f"{Colors.CYAN}[>] Mật khẩu ứng dụng: {Colors.END}")
        gmail_accounts.append((email, password))
        account_num += 1
    
    if not gmail_accounts:
        print(f"{Colors.RED}[!] Vui lòng nhập ít nhất một tài khoản Gmail!{Colors.END}")
        return

    print(f"\n{Colors.GREEN}[✓] Đã thêm {len(gmail_accounts)} tài khoản Gmail{Colors.END}")
    
    print(f"\n{Colors.YELLOW}[*] Nhập thông tin gửi email:{Colors.END}")
    

    while True:
        receiver_email = input(f"{Colors.CYAN}[>] Email người nhận: {Colors.END}")
        is_blocked, reason = email_blocker.is_blocked(receiver_email)
        
        if is_blocked:
            show_warning_banner(reason)
            print(f"\n{Colors.YELLOW}[*] Vui lòng nhập email khác.{Colors.END}")
            continue
        break

    print(f"\n{Colors.YELLOW}[*] SPAM MAIL VIP PRO{Colors.END}")
    
    subject = input(f"\n{Colors.CYAN}[>] Tiêu đề email: {Colors.END}")
    print(f"{Colors.CYAN}[>] Nội dung email (nhấn Enter hai lần để kết thúc):{Colors.END}")
    
    body_lines = []
    while True:
        line = input()
        if line == "":
            break
        body_lines.append(line)
    body = "\n".join(body_lines)
    
    while True:
        try:
            num_sends = int(input(f"\n{Colors.CYAN}[>] Số lượng email muốn gửi cho mỗi tài khoản: {Colors.END}"))
            if num_sends > 0:
                break
            print(f"{Colors.RED}[!] Vui lòng nhập số lớn hơn 0!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}[!] Vui lòng nhập một số hợp lệ!{Colors.END}")
    
    while True:
        try:
            delay = float(input(f"{Colors.CYAN}[>] Thời gian chờ giữa các lần gửi (giây): {Colors.END}"))
            if delay >= 0:
                break
            print(f"{Colors.RED}[!] Thời gian chờ không thể âm!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}[!] Vui lòng nhập một số hợp lệ!{Colors.END}")

    loading_effect("Đang chuẩn bị gửi email")
    clear_screen()
    print_banner()

    total_success = 0
    total_fail = 0
    start_time = datetime.now()
    all_fake_emails = []  

    total_emails = len(gmail_accounts) * num_sends
    current_email = 0

    print(f"\n{Colors.YELLOW}[*] Bắt đầu tiến trình gửi email...{Colors.END}\n")
    
    for account_num, (email, password) in enumerate(gmail_accounts, 1):
        print(f"\n{Colors.YELLOW}[*] Đang sử dụng tài khoản {account_num}: {email}{Colors.END}")
        email_sender = EmailSender(email, password)
        
        for i in range(num_sends):
            current_email += 1
            success, fake_email = email_sender.send_email(receiver_email, subject, body)

            if success:
                total_success += 1
                all_fake_emails.append((email, fake_email))
                success_animation(f"Đã gửi thành công email [{current_email}/{total_emails}] từ '{fake_email}'")
            else:
                total_fail += 1
                error_animation(f"Gửi thất bại email [{current_email}/{total_emails}]")
            
            fancy_progress_bar(current_email, total_emails, success)
            
            if current_email < total_emails:
                print()
                countdown_effect(int(delay))

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    print(f"\n\n{Colors.YELLOW}╔═══════════════ KẾT QUẢ ═══════════════╗{Colors.END}")
    print(f"{Colors.CYAN}║ Tổng số tài khoản: {Colors.YELLOW}{len(gmail_accounts):<15}{Colors.CYAN}║{Colors.END}")
    print(f"{Colors.CYAN}║ Tổng số email đã gửi: {Colors.YELLOW}{total_emails:<14}{Colors.CYAN}║{Colors.END}")
    print(f"{Colors.GREEN}║ ✓ Thành công: {total_success:<22}{Colors.GREEN}║{Colors.END}")
    print(f"{Colors.RED}║ ✗ Thất bại: {total_fail:<24}{Colors.RED}║{Colors.END}")
    print(f"{Colors.CYAN}║ Thời gian thực thi: {duration:.1f}s{' ' * (13 - len(str(int(duration))))}{Colors.CYAN}║{Colors.END}")
    print(f"{Colors.YELLOW}╚════════════════════════════════════════╝{Colors.END}")

    if all_fake_emails:
        print(f"\n{Colors.YELLOW}[*] Danh sách email giả đã sử dụng:{Colors.END}")
        current_account = None
        for idx, (account, fake_email) in enumerate(all_fake_emails, 1):
            if account != current_account:
                current_account = account
                print(f"\n{Colors.YELLOW}Từ tài khoản: {account}{Colors.END}")
            print(f"{Colors.CYAN}  {idx}. {fake_email}{Colors.END}")

    print(f"\n{Colors.GREEN}[✓] Hoàn thành nhiệm vụ!{Colors.END}")
    print(f"{Colors.YELLOW}[*] Cảm ơn bạn đã sử dụng tool của TienDev{Colors.END}")

if __name__ == "__main__":
    if not key_verify():
        exit()

    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.RED}[!] Đã dừng chương trình!{Colors.END}")
    except Exception as e:
        print(f"\n{Colors.RED}[!] Lỗi không mong muốn: {str(e)}{Colors.END}")
    finally:
        input(f"\n{Colors.YELLOW}[*] Nhấn Enter để thoát...{Colors.END}")